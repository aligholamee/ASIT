import asit

print(asit.processor_family)
print(asit.arc)
print(asit.os_name)