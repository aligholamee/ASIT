# ASIT
<p align="center">
    <a href="#logo" alt="sit logo">
        <img src="http://uupload.ir/files/0ndf_capture.png" /></a>
</p>
<p align="center">
Advanced System Information Toolbox Library.
</p>

---

<p align="center">
    <a href="#travis" alt="travis ci">
        <img src="https://travis-ci.com/aligholamee/pysys.svg?token=gYMHKihsfvyCN8TKR6jd&branch=master" /></a>
        <a href="https://badge.fury.io/py/asit"><img src="https://badge.fury.io/py/asit.svg" alt="PyPI version" height="18"></a>
    <a href="https://codecov.io/gh/aligholamee/pysys">
        <img src="https://codecov.io/gh/aligholamee/pysys/branch/master/graph/badge.svg" /></a>

</p>
