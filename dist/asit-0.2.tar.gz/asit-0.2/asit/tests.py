from asit import Asit as sit

print(sit.processor_family)
print(sit.arc)
print(sit.os_name)